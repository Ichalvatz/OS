
#!/bin/bash

date
current_time=$(date +%s)
let double_time=current_time*2
echo " Current time in seconds: $current_time, Double current time in seconds: $double_time"

for i in {1..20}; do
	echo "Number : $i"
done
